# Paper A Index

- Paper source: `papers/paperA/text/paper.tex`
- Bibliography: `papers/paperA/text/refs.bib`
- Artifact guide: `papers/paperA/artifacts/ARTIFACT_README.md`
- Claims context: `papers/paperA/context/gpt_a1_claims.md`
- Artifact requirements: `papers/paperA/context/artifact_requirements.md`
