# GPT Evidence Pack v4 (Paper A)

## Preflight Status

- `python -m pytest -q`: exit `0` (logs: `build/paperA_preflight_out_v4/pytest_q.stdout.txt`, `build/paperA_preflight_out_v4/pytest_q.stderr.txt`)
- `python tools/independent_check.py --paperA`: exit `0` (logs: `build/paperA_preflight_out_v4/independent_check_paperA.stdout.txt`, `build/paperA_preflight_out_v4/independent_check_paperA.stderr.txt`)
- `make -C papers/paperA clean paper`: exit `0` (logs: `build/paperA_preflight_out_v4/make_clean_paper.stdout.txt`, `build/paperA_preflight_out_v4/make_clean_paper.stderr.txt`)

## Artifact Freshness (timestamp + sha256)

- `papers/paperA/artifacts/tables/results_bitexact.csv` | mtime `2026-02-27T17:46:54` | sha256 `bce8fe95bb360214437ee0d87c531ff8f80a8bebc3dd06c4001a1cf109d224b2`
- `papers/paperA/artifacts/tables/results_qor.csv` | mtime `2026-02-27T17:46:54` | sha256 `2fb3c1574aa88d34cb6a919f188f715e9cd3ca8f8c2449663645594bd5bed1f1`
- `papers/paperA/artifacts/tables/results_throughput.csv` | mtime `2026-02-27T17:46:54` | sha256 `9309dec3620908b2fe4508f735c79c215e620281e79579e3095b28bc58d6d446`
- `papers/paperA/artifacts/evidence/vivado_coverage_report.md` | mtime `2026-02-27T17:46:54` | sha256 `311ebf909b88fa8900900219b74098b30366e5c9ecfa90354940f9c697a91b89`

## Table Previews (real data)

### Bitexact (`papers/paperA/artifacts/tables/results_bitexact.csv`)

| benchId | N | E | ticks | verify_ok | mismatches_len | digestMatchOk | independent_check_ok | trace_present | bench_report_path |
|---|---|---|---|---|---|---|---|---|---|
| B1 | 2 | 3 | 20 | true | 0 | true | true | true | build/audit_min/bench_verify/b1/example_b1_small_subgraph/bench_report.json |
| B2 | 64 | 1024 | 20 | true | 0 | true | true | true | build/audit_min/bench_verify/b2/B2_mid_64_1024/bench_report.json |
| B3 | 302 | 7500 | 20 | true | 0 | true | true | true | build/audit_min/bench_verify/b3/B3_kernel_302_7500/bench_report.json |
| B4 | 8 | 12 | 2 | true | 0 | true | - | true | build/bench_verify_b4/B4_celegans_external_bundle/bench_report.json |
| B5 | 96 | 1800 | 2 | - | - | true | - | true | build/bench_verify_b5_family/B5_synth_96_1800_s503/bench_report.json |
| B6 | 3 | 2 | 2 | - | - | true | true | true | build_hw/b6/B6_delay_small/bench_report.json |

### QoR (`papers/paperA/artifacts/tables/results_qor.csv`)

| benchId | ii | latencyCycles | lut | ff | bram | dsp | wns | fmax_est | hls_csim_ok | hls_csynth_ok | vivado_impl_ok | bench_report_path |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| B1 | 32 | 31 | 1148 | 355 | 0 | 0 | 1.129 | 258.331181 | true | true | true | build/audit_min/bench_verify/b1/example_b1_small_subgraph/bench_report.json |
| B2 | 614 | 613 | 4818 | 4738 | 1 | 1 | 0.957 | 247.341083 | true | true | true | build/audit_min/bench_verify/b2/B2_mid_64_1024/bench_report.json |
| B3 | 2746 | 2745 | 3172 | 3110 | 7 | 1 | 0.988 | 249.252243 | true | true | true | build/paperA_b3_vivado/B3_kernel_302_7500/bench_report.json |
| B4 | 100 | 99 | 2698 | 2680 | 0 | 0 | - | 200 | true | true | false | build/bench_verify_b4/B4_celegans_external_bundle/bench_report.json |
| B5 | 892 | 891 | 4561 | 5148 | 6 | 1 | - | 200 | true | true | false | build/bench_verify_b5_family/B5_synth_96_1800_s503/bench_report.json |
| B6 | 67 | 66 | 1928 | 1098 | 1 | 0 | - | 200 | true | true | false | build_hw/b6/B6_delay_small/bench_report.json |

### Throughput (`papers/paperA/artifacts/tables/results_throughput.csv`)

| benchId | cpp_ticks_per_sec | hw_ticks_per_sec_est | notes | hwBenchReportPath |
|---|---|---|---|---|
| B1 | 17689.675345 | 8072849.392922 | estimated_from_clk_wns_ii | build/audit_min/bench_verify/b1/example_b1_small_subgraph/bench_report.json |
| B2 | 14512.545345 | 402835.640642 | estimated_from_clk_wns_ii | build/audit_min/bench_verify/b2/B2_mid_64_1024/bench_report.json |
| B3 | 1305.954434 | 90769.207309 | estimated_from_clk_wns_ii | build/paperA_b3_vivado/B3_kernel_302_7500/bench_report.json |
| B4 | 1432.730447 | 2000000 | estimated_from_clk_wns_ii;vivado=FAIL | build/bench_verify_b4/B4_celegans_external_bundle/bench_report.json |
| B5 | 1662.200901 | 224215.246637 | estimated_from_clk_wns_ii;vivado=FAIL | build/bench_verify_b5_family/B5_synth_96_1800_s503/bench_report.json |
| B6 | 1444.705702 | 2985074.626866 | estimated_from_clk_wns_ii;vivado=FAIL | build_hw/b6/B6_delay_small/bench_report.json |

## Consistency Checks

- `bitexact_B1`: PASS
- `bitexact_B2`: PASS
- `bitexact_B3`: PASS
- `qor_vivado_B1`: PASS
- `qor_vivado_B2`: PASS
- `qor_vivado_B3`: PASS
- `qor_vivado_false_B4`: PASS
- `qor_vivado_false_B5`: PASS
- `qor_vivado_false_B6`: PASS
- `paper_no_false_success_for_B4_B5_B6` (best-effort text scan): PASS

## What We Can Claim Safely

- B1/B2/B3 have `verify_ok=true`, `mismatches_len=0`, `digestMatchOk=true` in `results_bitexact.csv`.
- B1/B2/B3 have `vivado_impl_ok=true` with numeric `wns` and `fmax_est` in `results_qor.csv`.
- B4/B5/B6 currently show `vivado_impl_ok=false` in `results_qor.csv`; they are not Vivado implementation successes.
- Independent checker runs and returns exit 0 for the Paper A canonical set.

## What We Cannot Claim Yet

- No on-board measurement claims (power/latency on physical FPGA).
- No Vivado impl success claim for B4/B5/B6 until their status flips to true with supporting logs/reports.

## Reproducible Commands

```bash
python -m pytest -q
python tools/independent_check.py --paperA
make -C papers/paperA clean paper
python tools/paperA/build_review_pack_v3.py
```

## Paths

- `papers/paperA/text/paper.pdf`
- `papers/paperA/artifacts/tables/results_bitexact.csv`
- `papers/paperA/artifacts/tables/results_qor.csv`
- `papers/paperA/artifacts/tables/results_throughput.csv`
- `papers/paperA/artifacts/evidence/vivado_coverage_report.md`
- `papers/paperA/artifacts/evidence/checksums.sha256`
- `build/paperA_preflight_out_v4`

## LaTeX Warnings (severity)

- Severe errors detected: `Undefined citation`
- Encoding anomaly (`decision=[]GO^^D`) detected in log: `yes`
- Minimal fix proposal (not applied): replace non-ASCII smart quotes around `GO` in affected `.tex` lines with plain ASCII `"GO"`.
