# Paper A boardless bundle (repro)

This bundle contains the boardless evidence files used by Paper A.

## Reproduction commands (repo root)

```bash
python -m pytest -q
python tools/independent_check.py --paperA
make -C papers/paperA paper
```

## Included evidence

- `paperA.pdf`
- `review_pack_v4.md`
- `tables/results_bitexact.csv`
- `tables/results_qor.csv`
- `tables/results_throughput.csv`
- `evidence/vivado_coverage_report.md`
- `evidence/independent_check.stdout.txt`
- `evidence/independent_check.exitcode.txt`

Notes:
- This is a boardless package; it does not include toolchains.
- Throughput values in `results_throughput.csv` are estimates, not on-board measurements.
